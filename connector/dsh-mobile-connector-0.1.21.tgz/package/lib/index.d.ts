import z from "@deepseek-ai/schemastery";
import { Context, Volatile } from "@deepseek-ai/cordis";
//#region src/config.d.ts
interface ConnectorConfig {
  /** 中转地址(wss)。有默认值（内置中转），面板里可换成自部署的。 */
  relayUrl: Volatile<string>;
  /** 仅允许非公网地址的明文联调，默认关闭。 */
  allowInsecureLocal: Volatile<boolean>;
  /** 允许公网明文（用户自部署中转、暂无域名/证书）。默认关，由用户显式打开。 */
  allowInsecurePublic: Volatile<boolean>;
  /** 连接器令牌的凭据引用;本体走 ctx.credentials,不进配置文件。 */
  relayTokenRef: Volatile<string | undefined>;
  /**
   * **直连拓扑**的监听端口(契约 §14.6 的第一跳)。`0` = 不监听(只走中转)。
   *
   * 没配时落到默认值（`listenPortOrDefault`），**不是 0** —— 默认值与"为什么"只有
   * 一处表达，见下面的 `DEFAULT_LISTEN_PORT`。
   */
  listenPort: Volatile<number>;
  /** 监听地址。没配时落到 `listenHostOrDefault`（默认 `0.0.0.0`）；要收窄时显式写。 */
  listenHost: Volatile<string>;
  /** 推送摘要粒度。 */
  pushDigest: Volatile<'rich' | 'doorbell'>;
  /** 单帧上限。 */
  frameLimitBytes: Volatile<number>;
  /** 超过此体积的对象改走重取,不内联。 */
  refetchThresholdBytes: Volatile<number>;
  /** 增量缓冲的帧数上界。 */
  windowFrames: Volatile<number>;
  /** 增量缓冲的字节上界。 */
  windowMaxBytes: Volatile<number>;
}
declare const Config: z<Schemastery.ObjectS<NoInfer<{
  relayUrl: z<string, string, "volatile-defined">;
  allowInsecureLocal: z<boolean, boolean, "volatile-defined">;
  allowInsecurePublic: z<boolean, boolean, "volatile-defined">;
  relayTokenRef: z<string, string, "volatile">;
  listenPort: z<number, number, "volatile-defined">;
  listenHost: z<string, string, "volatile-defined">;
  pushDigest: z<"rich" | "doorbell", "rich" | "doorbell", "volatile-defined">;
  frameLimitBytes: z<number, number, "volatile-defined">;
  refetchThresholdBytes: z<number, number, "volatile-defined">;
  windowFrames: z<number, number, "volatile-defined">;
  windowMaxBytes: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  relayUrl: z<string, string, "volatile-defined">;
  allowInsecureLocal: z<boolean, boolean, "volatile-defined">;
  allowInsecurePublic: z<boolean, boolean, "volatile-defined">;
  relayTokenRef: z<string, string, "volatile">;
  listenPort: z<number, number, "volatile-defined">;
  listenHost: z<string, string, "volatile-defined">;
  pushDigest: z<"rich" | "doorbell", "rich" | "doorbell", "volatile-defined">;
  frameLimitBytes: z<number, number, "volatile-defined">;
  refetchThresholdBytes: z<number, number, "volatile-defined">;
  windowFrames: z<number, number, "volatile-defined">;
  windowMaxBytes: z<number, number, "volatile-defined">;
}>>, "plain">;
//#endregion
//#region src/dsh/caps.d.ts
/** 通道对外公布的能力位。 */
interface Caps {
  /** 会话流与历史。必需服务缺失时插件不会加载，所以这里通常为 true。 */
  sessions: boolean;
  /** 增量缓冲与幂等表落盘；缺它保证不了 I7 / I8。 */
  storage: boolean;
  /** 审批接管。 */
  approval: boolean;
  /** 提问（含计划审查）。 */
  questions: boolean;
  /** 后台任务列表与停止。 */
  jobs: boolean;
  /** 子代理树。 */
  subagents: boolean;
  /**
   * `@` 候选（文件 / 目录 + 跨会话引用）。
   *
   * **两个面都在才算**：手机那边是一张面板（拼音节流查一次），
   * 只有一个面时面板要么只列文件、要么只列会话 —— 那是两条不同的能力，
   * 不该让用户猜"为什么少一半"。所以本字段是**与**，判据见 {@link referencesAvailable}。
   */
  references: boolean;
  /**
   * 插件清单与启停（`pluginManager` 服务在不在）。
   *
   * 本仓只透传清单与行级启停；**安装 / 卸载 / 升级不在能力位里** ——
   * 那是同一台电脑上另一类动作，不靠一个 bool 张冠李戴。
   */
  plugins: boolean;
  /**
   * 工作区文件面（目录清单 + 文本分页读）。
   *
   * 只覆盖"看文件"这一屏：**`readBytes` 与 `changes` 不在里面**（前者撞单帧预算、
   * 后者是另一条订阅面，见 `dsh/files.ts` 的文件头）。
   */
  files: boolean;
  /**
   * 改动面（`file.changes`）：这一轮改了哪些文件、各增删多少行。
   *
   * **数据仍然是桌面的记录**（宿主 `workspaceChanges`），手机只是画成一张卡。
   * 缺了不画卡片（老连接器 / 没装 workspace-changes 的部署）。
   */
  changes: boolean;
  /** 设置读写面。 */
  settings: boolean;
  /** 凭据面（手机侧只有设置页的密钥写面）。**必需服务**，所以通常为 true。 */
  credentials: boolean;
  /**
   * 局域网直连可拨（`listenPort` 非 0 且监听面真的起来了）。
   *
   * 它**不是**"能不能连"——中转一直都在。它是"直连这条路存在吗"：
   * 手机上据此决定要不要显示"同一网络"这一项，而不是让用户点一个
   * 必然拨不通的地址。
   */
  direct: boolean;
}
//#endregion
//#region src/transport/channels.d.ts
/**
 * 传输面的**通道注册表**：每个"连接方式"一个通道，各自独立启停。
 *
 * ## 它解决什么
 *
 * 传输面原来是一把开关：`startTransport` / `stopTransport` 同时起停**拨号连接
 * （中转）与直连监听面**，`transportRunning` 一个布尔。2026-10-17 用户原话：
 * 「不是有两中方式为啥就一个开关？……后面我要是再加新的方式也就一个开关吗？」
 *
 * 所以传输面按**方式**建模：每个通道有 id / 标签 / start / stop / running，
 * 管理面与 UI 都按注册表枚举渲染。**加第三种方式（Tailscale、服务器中转……）
 * 只是往注册表加一个端口** —— 管理面路由与 UI 开关的形状不变，这条由
 * `tests/admin-face.test.ts`（路由按通道生成）与 `tests/client-panel.test.ts`
 * （UI 按通道枚举）两道断言钉住。
 *
 * ## 两条通道的语义差异（停一条不碰另一条）
 *
 * - `relay`（中转拨号）：`relay-link.ts` 的控制连接 + 每设备一条数据连接，
 *   断开自愈（退避重连）。停它 = 关控制面与所有数据连接，**不碰**直连。
 * - `direct`（直连监听）：`listener.ts` 的 WS 服务端 + 已接受的连接。
 *   停它 = 停止接受并关掉已接受的连接（`tests/listener.test.ts` 有覆盖），
 *   **不碰**中转。
 *
 * 两条路各自持独立的 Connection 对象（`listener.ts` 文件头"为什么不复用拨号
 * 那条连接"），所以"停一条"在代码路径上就是可能的，不需要加锁或仲裁。
 *
 * ## 失败必须带到界面上
 *
 * 启动单条通道失败（端口被占）时错误**原样抛出**，由管理面归一成 400 + 原因
 * （照 `routes.ts` 的 `badRequest` 模式），通道保持"未运行"。静默失败会让
 * 操作者以为开关生效了。
 */
/** 一个通道的当前状态（管理面与 UI 的唯一数据源）。 */
interface ChannelState {
  /** 稳定 id（`relay` / `direct`）。URL 与 UI 都用它，不改名。 */
  readonly id: string;
  /** 给人看的标签（界面词，与协议字段无关）。 */
  readonly label: string;
  /** 此刻在跑吗。 */
  readonly running: boolean;
  /**
   * 跑着的这条**真的连上了吗**。只有"拨出去"的通道有这件事实（中转控制面）；
   * 直连是监听面，没有"连上"这个状态，所以缺省不报。
   *
   * 面板的「连接」卡要答"手机那头通没通"，`running` 答不了
   * （`start()` 之后到 `open` 之前也是 running）。
   */
  readonly connected?: boolean;
  /** 一行事实：拨向哪 / 监听在哪 / 为什么没配。 */
  readonly detail: string;
}
//#endregion
//#region src/index.d.ts
declare const name = "dsh-mobile-connector";
declare const inject: string[];
/** 发布给宿主的服务面。手机端的能力门控读 `caps()`。 */
interface ConnectorService {
  caps(): Caps;
  metrics(): Readonly<Record<string, number>>;
  /**
   * 传输面按"方式"分的通道列表（中转拨号 / 直连监听）。
   *
   * 2026-10-17 用户要求「两个方式两个开关」：原来一把 `startTransport` 同时
   * 起停两条，加第三种方式时 UI 与管理面都要改形状；现在是**注册表**，
   * 加一种方式只是加一个端口。见 `transport/channels.ts`。
   */
  channels(): readonly ChannelState[];
  /** 起（`running: true`）或停（`running: false`）一条传输通道。 */
  setChannel(id: string, running: boolean): Promise<void>;
}
declare function apply(ctx: Context, config: ConnectorConfig): void;
//#endregion
export { Config, ConnectorService, apply, inject, name };